
import PestNotification from "@/components/forms/pestNotification"


function TestePage() {
return <PestNotification />
}

export default TestePage